print ("hello world")

name = 'bowen'
print(name)

print('My name is ' + name  + '.')
print('My name is', name ,'.')
print('My name is %s.' %(name))
print(f'My name is {name}.')

first_name  = "Bowen"
last_name = 'Zheng'
profession = 'Student'
affiliation = 'Yonsei University'
print('Hello, %s %s. You are a %s at %s.'
      %(first_name , last_name, profession, affiliation))
print(f'Hello, {first_name} {last_name}. You are a {profession} at {affiliation}.')