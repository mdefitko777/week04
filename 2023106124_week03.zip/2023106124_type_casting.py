print('This program adds two numbers.')
operand1= int(input('number 1: '))
operand2 = int(input('number 2: '))
print(f'{operand1} + {operand2} = {operand1 + operand2}')
print(operand1 , type(operand1))

print('This program adds two numbers.')
operand1= input('number 1: ')
operand2 = input('number 2: ')
print(f'{operand1} + {operand2} = {operand1 + operand2}')
print(operand1 , type(operand1))

# name = Zheng Bowen